function tree = pruneBPTnbiterations(tree,NbIter)

N = length(tree);
Nbleaves = (N+1)/2;
for i=1:N
    tree(i).pruning = 0;
end

IterMax = tree(end).nodeinfo.iteration;
NbIter = round(NbIter);

if NbIter>=IterMax
    tree(end).pruning = 1;
else
    IterCut = NbIter;
    SetLeaves = 1:Nbleaves;
    
    SetNode = [];
    while ~isempty(SetLeaves)
        leaf = SetLeaves(1);
        p = tree(leaf).nodeinfo.branch; % the branch of the leaf
        IterBranch = [tree(p).nodeinfo];  
        IterBranch = [IterBranch.iteration]; % build iteration of the whole branch to that leaf
        node = p(find(IterBranch<=IterCut,1,'last')); % for each leaf, find the last node in the branch
        % that has an iteration build <= the nbregions. This is because we
        % want to select the nodes from the root to the IterCut.
        if isempty(node) % if there are no regions with iteration less than the number of regions, then
            node = leaf; % the leaf region and branch will be pruned and shown in the final segmentation map
            SetLeaves(1) = []; % remove that leaf.
        else
            leaves = tree(node).nodeinfo.leaves; % get the leaves of that parent node.
            SetLeaves = setdiff(SetLeaves,leaves); % remove the common leaves from the leaves list
        end
        SetNode = cat(2,SetNode,node); %
    end
    
    for i=1:length(SetNode)
        tree(SetNode(i)).pruning = 1;
    end
    
end

