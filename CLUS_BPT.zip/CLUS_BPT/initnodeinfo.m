function s = initnodeinfo
% initializa nodeinfo
s.sibling = [];
s.leaves = [];
s.nbleaves = 0;
s.issiblingleaf = false;
s.children = [];
s.parent = [];
s.iteration = [];