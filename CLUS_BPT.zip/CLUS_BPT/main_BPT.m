%% Main for BPT construction and processing
%% Initial segmentation

% first get a pre-segmentation of the image (optional, but advised...)
% Several methods are possible, such as watershed segmentation, SLIC or
% mean shift clustering (code is available online for SLIC and MSC)
% Here is provided the multidimensional watershed algorithm

D = load('Data/paviaU.mat');
pavia = D.paviaU;
imOut = pavia;
imrgb = imread('Data/Pavia_rgb.png');


Gt = load('Data/paviaU_gt.mat');
Gt = Gt.paviaU_gt;

% Segmentation by multidimensional watershed
% ------------------------------------------
SEG = multidimwatershed(imOut,'supremum');
initsegmap = SEG.whed;


%% build data structures

% The available region model is the region-wise mean vector "R_mean" 
% with a bunch of associated metrics (Euclidean, L1 and Linfinity norms, SAM,
% Kullback-Leibleir and Jensen-Shannon for the mean model)

% The field specmerging in structure DAT has to be specified as "merging_mean"

DAT = struct;
DAT.data = imOut;  
DAT.initsegmap = initsegmap; % initial segmentation map
DAT.regionmodel = @R_mean;
DAT.mergingcriterion = @O_SAM;
DAT.specmerging = @merging_mean;
DAT.prioritysize = @priority_size;


%% build BPT

T = buildBPT(DAT);


%% Process/prune BPT

% BPT processing can be done in different way, and must be specifically
% tuned to the desired goal.

% A simple way to process the BPT is to extract a given number of regions N,
% which will constitute a partition featuring the N most dissimilar regions
% created during the construction of the BPT.

%prunedtree = pruneBPTnbregions(T,50); % N=10
prunedtree = pruneBPTnbregions(T,50); % N=10

%% Display partition

segregions = retrievesegmentation(prunedtree,initsegmap,'regions',imrgb);
drawborders(imrgb,segregions,'red');
imrgbmean = displaysegmentationfalsecolors(segregions,imrgb);
figure, imshow(imrgbmean)
figure, imshow(segregions)

tic
PosNodes = [prunedtree.pruning];
node = prunedtree(logical(PosNodes)); % tree nodes containing the remaining regions
%nodeDescriptors = [node(1:end).descriptors];

nodeDescriptors = [node(1:end).descriptors];
nodeModels = [nodeDescriptors.model];

nodeModelsTranspose = transpose(nodeModels);

nodeRegionsTmp = zeros(size(initsegmap));

nodeRegions = zeros(size(initsegmap));
nodeRegions(:,:,1) = zeros(size(initsegmap));
nodeRegions(:,:,2) = zeros(size(initsegmap));


for j=1:size(nodeModels,1)
    for i=1:length(node)

        if isempty(node(i).nodeinfo.leaves)
            % the considered node is a leaf
            %nodeRegions(initsegmap==node(i).label) = nodeModels(1,i); % 1 subspace 
            nodeRegionsTmp(initsegmap==node(i).label) = nodeModels(j,i);
            nodeRegions(:,:,j) = nodeRegionsTmp;
        else
            ind = ismember(initsegmap,node(i).nodeinfo.leaves);
            %nodeRegions(ind) = nodeModels(1,i); %1 subspace 
            nodeRegionsTmp(ind) = nodeModels(j,i);  %segmentation map containing regions model values!
            nodeRegions(:,:,j) = nodeRegionsTmp;
        end
    end
end


nodeRegions1 = reshape(nodeRegions(:,:,1),size(nodeRegions,1)*size(nodeRegions,2),1);
nodeRegions2 = reshape(nodeRegions,size(nodeRegions,1)*size(nodeRegions,2),size(nodeRegions,3));

%%%% PCA %%%%
[coeff, score] = pca(nodeRegions2);
reducedDimension = coeff(:,1);
reducedData = nodeRegions2 * reducedDimension;

%%%% Kmeans
[L,Centers] = kmeans(reducedData,10);
toc
%%% Remove background information for score calculation
pos = find(Gt(:) == 0);
Gt(pos) = [];
L(pos) = [];

Gt = Gt .' ; 
Gt = double(Gt);

%% Calculate purity and NMI scores.
z = nmi(Gt,L);
purity_score = Purity(Gt, L);

%%%% save kmeans labels for plot on Python %%%%%
save('Labels.mat','L');


% 
% L1 = reshape(L,610,340);
% 
% drawborders(imrgb,L1,'red');
% 
% [w h]=size(L1);
% imOut=zeros(w,h,3);
% map=[192 192 192;0 255 0;0 255 255;0 128 0; 254 0 255;165 82 41;128 0 128;255 0 0;255 255 0];
%         for i=1:w
%             for j=1:h
%                 switch(L1(i,j))
%                     case(1)
%                         imOut(i,j,:)=uint8(map(1,:));
%                     case(2)
%                         imOut(i,j,:)=uint8(map(2,:));
%                     case(3)
%                         imOut(i,j,:)=uint8(map(3,:));
%                     case(4)
%                         imOut(i,j,:)=uint8(map(4,:));
%                     case(5)
%                         imOut(i,j,:)=uint8(map(5,:));
%                     case(6)
%                         imOut(i,j,:)=uint8(map(6,:));
%                     case(7)
%                         imOut(i,j,:)=uint8(map(7,:));
%                     case(8)
%                         imOut(i,j,:)=uint8(map(8,:));
%                     case(9)
%                         imOut(i,j,:)=uint8(map(9,:));
%                 end
%             end
%         end
% imOut=uint8(imOut);
% figure, imshow(imOut);
% 
