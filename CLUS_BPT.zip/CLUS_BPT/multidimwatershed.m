function S = multidimwatershed(im,method)

% S = multidimwatershed(IM,method)
% Performs on the image IM the following multidimentional watershed
% segmentation by performing a watershed transformation of the image
% gradient, the gradient being defined according to the string 'method':
% - method = 'supremum' => performs morphological supremum gradient
% (structuring element is by default a 3x3 square).
%--------------------------------------------------------------------------
% The output is the structure S with the following fields:
% - 'gradient' contains the multidimensional gradient of the input image.
% - 'nowhed' contains the watershed segmentation with border pixels.
% - 'whed' contains the watersged segmantion with border pixels removed

if isequal(method,'supremum')==1
    [grad,mapnowhed] = supgrad(im);
else
    error('incorrect input method')
end

im = reshape(im,size(im,1)*size(im,2),size(im,3));
mapwhed = whed(mapnowhed,im);

S = struct;
S.gradient = grad;
S.nowhed = mapnowhed;
S.whed = mapwhed;
