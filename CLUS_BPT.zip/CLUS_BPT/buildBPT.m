function T = buildBPT(inputdata)

% define global variables
clearvars -global
global initsegmap
global I
global tree

% extract input parameters from input structure
initsegmap = inputdata.initsegmap;
I = inputdata.data; I = reshape(I,size(I,1)*size(I,2),size(I,3)); % (actual size, spatial size, band size)
R = inputdata.regionmodel;
O = inputdata.mergingcriterion;
spec_merging = inputdata.specmerging;
priority_size = inputdata.prioritysize;

%fprintf('Printing max initsegmap\n')
%max(initsegmap(:))


% BPT initialization step using the region model (R_Mean) and merging
% criterion (SAM)
tic
tree = initstructarray(R,O);
toc

% BPT update step
tic
updatestructarray(O,spec_merging,priority_size);
toc

% BPT completion step
completestructarray

% output
T = tree;
clearvars -global