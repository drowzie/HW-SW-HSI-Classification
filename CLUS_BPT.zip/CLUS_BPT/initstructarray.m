function tree = initstructarray(handleR,handleO)

fprintf('Initialization of the tree\n')
fprintf('~~~~~~~~~~~~~~~~~~~~~~~~~~\n')

global initsegmap

[m, n] = size(initsegmap);
N = max(initsegmap(:));
tree(2*N-1) = struct;
% The regionprops function returns the bounding boxes in a structure array
% Smallest rectangle containing the region
boxes = regionprops(initsegmap,'Boundingbox');  

%view the boxes obtained
%imshow(initsegmap)
%hold on
%for k = 1 : length(boxes)
%     BB = boxes(k).BoundingBox;
%     rectangle('Position', [BB(1),BB(2),BB(3),BB(4)],'EdgeColor','r','LineWidth',2) ;
%end


% each node in the tree has:
% a region label, 
% mean spectrum of the pixels in that region location, -> handlerR  
% bounding box of the region, 
% initialize node info: sibling, leaves, nbleaves, children, parent, iteration
% neigbours labels
% all distances to the neighbours

for i=1:N
    tree(i).label = i;
    tree(i).descriptors = handleR(i);
    bb = getboundingbox(boxes(i),[m n]); % get the exact bounding box for that region
    tree(i).descriptors.boundingbox = bb;
    tree(i).nodeinfo = initnodeinfo;
    tree(i).construction.neighbors = getneighlabel(initsegmap(bb(1):bb(2),bb(3):bb(4)),i);
    tree(i).construction.alldist = zeros(size(tree(i).construction.neighbors));
end
fprintf('Creating leaf structures: done\n')


% Updating the leaf structures representing the regions by going through 
% each region and its neighbours
%shortest distance neighbour is the sibling


for i=1:N
    neigh = tree(i).construction.neighbors;
    Nei = neigh(neigh>tree(i).label); 
    D = zeros(size(Nei));
    for j=1:length(Nei) % for all neighbours with labels greater than the current label (so that we go acessending order and not repeat the process with the past nodes)
        D(j) = handleO(tree(i).descriptors.model,tree(Nei(j)).descriptors.model); % calculate the spectral angle mapper
        ind = tree(Nei(j)).construction.neighbors == i;  %Find the index in the neighbour's neighbours list such that it equals the region in question (i)
        tree(Nei(j)).construction.alldist(ind) = D(j); % and write the same distance for that index (ind) D12=D21
    end
    tree(i).construction.alldist(neigh>tree(i).label) = D; % write the distances to the node i
    tree(i).construction.dist = min(tree(i).construction.alldist);
    ind = find(tree(i).construction.alldist==min(tree(i).construction.alldist),1,'first'); %find the index of the shortest distance neigbhour
    tree(i).nodeinfo.sibling = neigh(ind); %make it as sibling
    tree(i).nodeinfo.leaves = []; % no leaves
    tree(i).nodeinfo.iteration = 0; 
end
fprintf('Updating leaf structures: done\n')