D = load('Data/paviaU.mat');
pavia = D.paviaU;

pavia = reshape(pavia,size(pavia,1)*size(pavia,2),size(pavia,3));

[coeff, score] = pca(pavia);
reducedDimension = coeff(:,16);
reducedData = pavia * reducedDimension;

M32 = int32(reducedData);
fileID = fopen('spca_32_test.bin','w');
fwrite(fileID,M32,'int32');
fclose(fileID);